// This file implements a module where we define multiple data types
// to store represent boolean, arithmetic, commands and guarded commands from Parser and Lexer.
module FMProjectTypesAST

// type arithExpr does basic arithmetric operations
type arithExpr =
  | Num of float
  | StrA of (string)
  | TimesExpr of (arithExpr * arithExpr)
  | DivExpr of (arithExpr * arithExpr)
  | PlusExpr of (arithExpr * arithExpr)
  | MinusExpr of (arithExpr * arithExpr)
  | PowExpr of (arithExpr * arithExpr)
  | UPlusExpr of (arithExpr)
  | UMinusExpr of (arithExpr)
  | LogExpr of (arithExpr)
  | LnExpr of (arithExpr)
  | IndexExpr of (string * arithExpr)

// type boolExpr does basic bool operations
type boolExpr = 
  | Bool of (bool)
  | StrB of (string)
  | BitWiseAnd of (boolExpr * boolExpr)
  | BitWiseOr of (boolExpr * boolExpr)
  | LogAnd of (boolExpr * boolExpr)
  | LogOr of (boolExpr * boolExpr)
  | Neg of (boolExpr)
  | Equal of (arithExpr * arithExpr)
  | NotEqual of (arithExpr * arithExpr)
  | Greater of (arithExpr * arithExpr)
  | GreaterEqual of (arithExpr * arithExpr)
  | Less of (arithExpr * arithExpr)
  | LessEqual of (arithExpr * arithExpr)

// type guardCommand and type command are declared together as they are 
// mutually recursive types, and they do basic guarded commands and commands
type guardCommand = 
  | IfThen of (boolExpr * command)
  | FatBar of (guardCommand * guardCommand)
and command = 
  | Assign of (string * arithExpr) 
  | ArrayAssign of (string * arithExpr * arithExpr)
  | Skip 
  | Order of (command * command)
  | If of (guardCommand)
  | Do of (guardCommand)


